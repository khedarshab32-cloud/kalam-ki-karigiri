plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.kalamkikarigiri"; compileSdk = 35
    defaultConfig { applicationId = "com.kalamkikarigiri"; minSdk = 24; targetSdk = 35; versionCode = 8; versionName = "8.0.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("androidx.webkit:webkit:1.12.1")
}
