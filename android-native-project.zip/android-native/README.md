# Android background playback shell

This module is the native Android foundation for authorized/direct audio playback. It uses AndroidX Media3 `ExoPlayer` + `MediaSessionService`, which is the Android architecture intended for background playback and media notification controls.

The web UI remains in `../public`. A final release can host that UI with Capacitor/WebView while keeping `PlaybackService` as the native playback layer.

Do not feed this service extracted/ripped YouTube or Spotify audio. Only use URLs the app is authorized to stream.
